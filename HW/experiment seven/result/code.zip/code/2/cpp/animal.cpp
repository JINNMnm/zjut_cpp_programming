// C++ How to Program
// Debugging Problem (animal.cpp)

#include <iostream>
using std::cout;
using std::endl;

#include "../hpp/animal.hpp"


Animal::Animal( const int h, const int w)
{
   height = h;
   weight = w;
}

Animal::Animal( const Animal &a )
{
   height = a.height;
   weight = a.weight;
}

void Animal::print() const
{
   cout << "This animal's height and weight are as follows\n"
        << "Height: " << height << "\tWeight: " << weight << endl << endl;
}

int Animal::getHeight() const { return height; }

int Animal::getWeight() const { return weight; }

void Animal::setHeight( const int h ) { height = h; }

void Animal::setWeight( const int w ) { weight = w; }



